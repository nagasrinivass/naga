

Using a react template for Frankie's Bakery 


---NOTE:
Frankie's Bakery is a fictional business created for demonstrative purposes only


---WEBSITE TEMPLATE---
The original Author of the Template that is used came from the following two sources

From Author template
https://react-landing-page-template-93ne.vercel.app/#contact

https://github.com/issaafalkattan/React-Landing-Page-Template/tree/master